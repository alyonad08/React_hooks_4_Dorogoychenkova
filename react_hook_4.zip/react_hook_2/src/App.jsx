import {
  useCallback, useDeferredValue, useEffect, useMemo,
  useReducer, useRef, useState, useTransition,
} from 'react';
import { tasksReducer } from './tasksReducer.js';
import { useTheme } from './ThemeContext.jsx';
import { useLanguage } from './LanguageContext.jsx';
import { useOnlineStatus } from './hooks/useOnlineStatus.js';
import { ThemeToggle } from './components/ThemeToggle.jsx';
import { LanguageToggle } from './components/LanguageToggle.jsx';
import { AddTaskForm } from './components/AddTaskForm.jsx';
import { SearchBox } from './components/SearchBox.jsx';
import { TaskList } from './components/TaskList.jsx';

function makeTestTasks() {
  return Array.from({ length: 2000 }, (_, i) => ({
    id: 'test-' + Date.now() + '-' + i,
    text: 'Тестовая задача ' + (i + 1),
    done: false,
  }));
}

function loadTasks() {
  try {
    return JSON.parse(localStorage.getItem('tasks')) ?? [];
  } catch {
    return [];
  }
}

export default function App() {
  const { theme } = useTheme();
  const { t } = useLanguage();
  const [tasks, dispatch] = useReducer(tasksReducer, [], loadTasks);
  const online = useOnlineStatus();
  const [filter, setFilter] = useState('all');
  const [query, setQuery] = useState('');
  const deferredQuery = useDeferredValue(query);
  const [isPending, startTransition] = useTransition();
  const searchRef = useRef(null);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  const handleAdd = useCallback((text) => {
    dispatch({ type: 'add', task: { id: Date.now(), text, done: false } });
  }, []);
  const handleToggle = useCallback((id) => dispatch({ type: 'toggle', id }), []);
  const handleRemove = useCallback((id) => dispatch({ type: 'remove', id }), []);
  const handleRename = useCallback((id, text) => dispatch({ type: 'rename', id, text }), []);

  const visibleTasks = useMemo(() => {
    const q = deferredQuery.trim().toLowerCase();
    return tasks.filter((x) => {
      const byFilter = filter === 'all' || (filter === 'done' ? x.done : !x.done);
      return byFilter && x.text.toLowerCase().includes(q);
    });
  }, [tasks, deferredQuery, filter]);

  const doneCount = useMemo(() => tasks.filter((x) => x.done).length, [tasks]);

  const percent = useMemo(
    () => (tasks.length ? Math.round((doneCount / tasks.length) * 100) : 0),
    [tasks.length, doneCount]
  );

  useEffect(() => {
    function onKeyDown(e) {
      const tag = document.activeElement.tagName;
      if (e.key === '/' && tag !== 'INPUT' && tag !== 'TEXTAREA') {
        e.preventDefault();
        searchRef.current.focus();
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  return (
    <div className={'app ' + theme}>
      <div className="card">
        <header className="top">
          <h1>{t.title}</h1>
          <div className="top-actions">
            <LanguageToggle />
            <ThemeToggle />
          </div>
        </header>
        <p className="muted">{online ? '🟢 ' + t.online : '🔴 ' + t.offline}</p>
        <AddTaskForm onAdd={handleAdd} />
        <div className="toolbar">
          <SearchBox ref={searchRef} value={query} onChange={setQuery} placeholder={t.search} />
          <button onClick={() => searchRef.current.clear()}>{t.reset}</button>
        </div>
        <div className="tabs">
          {[['all', t.all], ['active', t.active], ['done', t.done]].map(([key, label]) => (
            <button
              key={key}
              className={filter === key ? 'active' : ''}
              onClick={() => startTransition(() => setFilter(key))}
            >
              {label}
            </button>
          ))}
        </div>
        <p className="muted">
          {t.total}: {tasks.length}, {t.completed}: {doneCount} ({percent}%)
          {isPending && ' · ' + t.updating}
        </p>
        <TaskList
          tasks={visibleTasks}
          onToggle={handleToggle}
          onRemove={handleRemove}
          onRename={handleRename}
        />
        <div className="toolbar">
          <button onClick={() => dispatch({ type: 'clearDone' })}>{t.clearDone}</button>
          <button onClick={() => dispatch({ type: 'addMany', tasks: makeTestTasks() })}>{t.addMany}</button>
          <button onClick={() => dispatch({ type: 'clearAll' })}>{t.clearAll}</button>
        </div>
      </div>
    </div>
  );
}