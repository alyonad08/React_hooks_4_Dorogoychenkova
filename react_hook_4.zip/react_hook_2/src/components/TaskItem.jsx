import { memo } from 'react';
import { useLanguage } from '../LanguageContext.jsx';

export const TaskItem = memo(function TaskItem({ task, onToggle, onRemove, onRename }) {
  const { t } = useLanguage();

  function handleRename() {
    const text = prompt(t.renamePrompt, task.text);
    if (text && text.trim()) onRename(task.id, text.trim());
  }

  return (
    <li className={task.done ? 'done' : ''}>
      <input type="checkbox" checked={task.done} onChange={() => onToggle(task.id)} />
      <span>{task.text}</span>
      <button onClick={handleRename}>{t.edit}</button>
      <button onClick={() => onRemove(task.id)}>×</button>
    </li>
  );
});