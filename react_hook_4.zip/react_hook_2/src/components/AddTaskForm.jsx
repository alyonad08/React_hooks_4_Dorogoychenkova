import { useId, useRef, useState } from 'react';
import { useLanguage } from '../LanguageContext.jsx';

export function AddTaskForm({ onAdd }) {
  const [text, setText] = useState('');
  const inputRef = useRef(null);
  const inputId = useId();
  const { t } = useLanguage();

  function handleSubmit(e) {
    e.preventDefault();
    const clean = text.trim();
    if (!clean) return;
    onAdd(clean);
    setText('');
    inputRef.current.focus();
  }

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor={inputId} className="sr">{t.newTask}</label>
      <input
        id={inputId}
        ref={inputRef}
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={t.newTask}
      />
      <button>{t.add}</button>
    </form>
  );
}